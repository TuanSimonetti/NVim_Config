# bun completions
[ -s "/home/gabs/.bun/_bun" ] && source "/home/gabs/.bun/_bun"