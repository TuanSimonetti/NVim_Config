export PATH="/opt/homebrew/opt/openjdk@11/bin:$PATH"
ANDROID_HOME=$HOME/Library/Android/sdk

export PATH="/opt/homebrew/opt/make/libexec/gnubin:$PATH"
export PATH="$HOME/Library/Android/sdk/build-tools/34.0.0/:$HOME/Library/Android/sdk/platform-tools/:$PATH"
