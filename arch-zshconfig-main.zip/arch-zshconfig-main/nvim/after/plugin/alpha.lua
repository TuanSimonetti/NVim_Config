require'alpha'.setup(require'alpha.themes.startify'.config)
