vim.keymap.set("n", "<C-\\>", function () vim.cmd("ToggleTerm direction=float") end)
vim.keymap.set("t", "<C-\\>", function () vim.cmd("ToggleTerm direction=float") end)
