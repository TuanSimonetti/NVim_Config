require("lualine").setup({
  extensions = { 'mason', 'nvim-tree', 'lazy', 'toggleterm' }
})
