vim.keymap.set("n", "<leader>pv", vim.cmd.Ex, { desc = "Open NetRW file browser" })
-- Record macro on register a
vim.keymap.set("n", "<leader>ma", "qai", { desc = "Record macro and enter insert mode" })
